import pygame
import sys
import math
import random
import time
from pygame.constants import K_ESCAPE, K_SPACE, MOUSEBUTTONDOWN, K_a, K_d
from pygame import mixer
pygame.mixer.pre_init(44100, 16, 2, 4096)
pygame.init()
keys = pygame.key.get_pressed()
width = 1200
height = 700
IsLeft = False
IsRight = False

win = pygame.display.set_mode((width, height))
pygame.display.set_caption("Flight Of Fantasy")
FFG = pygame.image.load('FFG.png')
PLAY = pygame.image.load('Play.png')
ABOUT = pygame.image.load('About.png')
BG = pygame.image.load('bg_.png')
AA1 =  [pygame.image.load("AP1 (1).png"), pygame.image.load("AP1 (2).png"), pygame.image.load("AP1 (3).png"), pygame.image.load("AP1 (4).png"), pygame.image.load("AP1 (5).png"), pygame.image.load("AP1 (6).png"), pygame.image.load("AP1 (7).png"), pygame.image.load("AP1 (8).png"), pygame.image.load("AP1 (9).png"), pygame.image.load("AP1 (10).png"), pygame.image.load("AP1 (11).png"), pygame.image.load("AP1 (12).png")]
AA2 =  [pygame.image.load("AP2 (1).png"), pygame.image.load("AP2 (2).png"), pygame.image.load("AP2 (3).png"), pygame.image.load("AP2 (4).png"), pygame.image.load("AP2 (5).png"), pygame.image.load("AP2 (6).png"), pygame.image.load("AP2 (7).png"), pygame.image.load("AP2 (8).png"), pygame.image.load("AP2 (9).png"), pygame.image.load("AP2 (10).png"), pygame.image.load("AP2 (11).png"), pygame.image.load("AP2 (12).png")]
AR1 =  [pygame.image.load("AR1 (1).png"), pygame.image.load("AR1 (2).png"), pygame.image.load("AR1 (3).png"), pygame.image.load("AR1 (4).png"), pygame.image.load("AR1 (5).png"), pygame.image.load("AR1 (6).png")]
AR2 =  [pygame.image.load("AR2 (1).png"), pygame.image.load("AR2 (2).png"), pygame.image.load("AR2 (3).png"), pygame.image.load("AR2 (4).png"), pygame.image.load("AR2 (5).png"), pygame.image.load("AR2 (6).png")]
AI1 = pygame.image.load("AL1.png")
AI2 = pygame.image.load("AL2.png")
AIM = pygame.image.load('aim.png')
AIM2 = pygame.image.load('aim2.png')
QUIT = pygame.image.load('Quit.png')
QUITTING = pygame.image.load("Quitting.png")
BLUR = pygame.image.load('blur.png')
ISL_1 = pygame.image.load('island_10.png')
ISL_3 = pygame.image.load('island_3.png')
ISL_4 = pygame.image.load('island_4.png')
ISL_5 = pygame.image.load('island_6.png')
STRTISL = pygame.image.load("start_island.png")
ABOUT_ME = pygame.image.load("About_ME.png")
GameOver = pygame.image.load("Game_Over.png")
JUMP = pygame.image.load("jump.png")
SLOW = pygame.image.load("slow.png")
SPEED = pygame.image.load("speed.png")
RES = pygame.image.load("Res.png")
RS = pygame.image.load("Res_effect.png")
SPD = pygame.image.load("speed_effect.png")
SLF = pygame.image.load("slow_fall.png")
JPB = pygame.image.load("jump_boost.png")
pygame.display.set_icon(FFG)
jump = mixer.Sound("jump.wav")
edie = mixer.Sound("enemy_diee.wav")
pdie = mixer.Sound("player_die.wav")
GLAR = [pygame.image.load("GLA (1).png"), pygame.image.load("GLA (2).png"), pygame.image.load("GLA (3).png"), pygame.image.load("GLA (4).png"), pygame.image.load("GLA (5).png"), pygame.image.load("GLA (6).png")]
GLARL = [pygame.image.load("GLAR (1).png"), pygame.image.load("GLAR (2).png"), pygame.image.load("GLAR (3).png"), pygame.image.load("GLAR (4).png"), pygame.image.load("GLAR (5).png"), pygame.image.load("GLAR (6).png")]
GLARR = [pygame.image.load("GRAR (1).png"), pygame.image.load("GRAR (2).png"), pygame.image.load("GRAR (3).png"), pygame.image.load("GRAR (4).png"), pygame.image.load("GRAR (5).png"), pygame.image.load("GRAR (6).png")]
GLAL = [pygame.image.load("GLA (1) - Copy.png"), pygame.image.load("GLA (2) - Copy.png"), pygame.image.load("GLA (3) - Copy.png"), pygame.image.load("GLA (4) - Copy.png"), pygame.image.load("GLA (5) - Copy.png"), pygame.image.load("GLA (6) - Copy.png")]
GLI = pygame.image.load("GLI (1).png")
GLIR = pygame.image.load("GLIR (1).png")
DAGGER =  pygame.image.load("dagger.png")
RES_SHEILD = pygame.image.load("Res_feild.png")
bigquit = pygame.image.load("quitbig.png")


class button():
    def __init__(self, color, width,height ,x , y):
        self.color = color
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def draw(self,win):
        pygame.draw.rect(win, self.color, (self.x,self.y,self.width,self.height),0)

    def isOver(self, pos):
        if pos[0] > self.x and pos[0] < self.x + self.width:
            if pos[1] > self.y and pos[1] < self.y + self.height:
                return True
        return False

def image( image_png, x, y):
     win.blit(image_png, (x,y))

click = False
def main_menu():
    IsQuit = False
    while True:
        keys = pygame.key.get_pressed()
        mpos = pygame.mouse.get_pos() 
        playhb = button((255, 255, 255), 440, 62, 380, 420)
        quhb = button((255, 255, 255), 208, 49, 605, 491)
        yesb = button((255, 255, 255), 100, 50, 408, 325)
        nob = button((255, 255, 255), 100, 50, 680, 325)
        playhb.draw(win)
        win.blit(BG, (0,0))
        quhb.draw(win)
        ffg = image(FFG, 345, 130)
        play = image(PLAY, 380, 420)
        about = image(ABOUT, 342, 464)
        quitting = image(QUITTING, 602, 482)
        abhb = button((255, 255, 255), 208, 49, 387, 484)
        clock = pygame.time.Clock()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == K_ESCAPE:
                    if IsQuit == True:
                        pygame.quit()
                        sys.exit()
            if event.type == pygame.KEYUP:
                IsQuit = True

            if event.type == pygame.MOUSEBUTTONUP:
                if playhb.isOver(mpos):
                    game()
                if yesb.isOver(mpos):
                    if IsQuit:
                        pygame.quit()
                        sys.exit()
                if nob.isOver(mpos):
                    IsQuit = False
                if quhb.isOver(mpos):
                    IsQuit = True
                if abhb.isOver(mpos):
                    Aboutme()
        if IsQuit == True:
            win.blit(BLUR, (0,0))
            nob.draw(win)
            yesb.draw(win)
            win.blit(QUIT, (345, 128))



        pygame.display.update()
        clock.tick(60)
        
def hitboxes(x ,y ,width ,height):
    pygame.draw.rect(win, (255,255,255), (x, y, width, height))


def game():
    #---------------------------------------------------------------------------------------------------
    #-----------------------------------------booleans--------------------------------------------------
    #---------------------------------------------------------------------------------------------------
    IsJumping = False
    IsRunning = True
    IsShooting = False
    click = False
    IswalkingRight = False
    IswalkingLeft = False
    attack = False
    IsRight = True
    IsLeft = False
    attackboxr = False
    attackboxl = False
    CanShoot = True
    menu = False
    IslDrw = True
    Isl1place = False
    Isl3place = False
    Isl4place = False
    Isl2place = False
    Isl1move = False
    Isl3move = False
    Isl4move = False
    Isl2move = False
    OnPlat = False
    Djump = False
    startermove = False
    Speed = False
    Jump = False
    Slow = False
    Res = False
    Place_powerup = False
    power1 = False
    power2 = False
    power3 = False
    power4 = False
    Enemy_Place = False
    enemyp1 = False
    enemyp2 = False
    enemyp3 = False
    enemyp4 = False
    idle = False
    enemyplaced = False
    dead = False
    taketime = False

    #---------------------------------------------------------------------------------------------------
    #-----------------------------------------variables-------------------------------------------------
    #---------------------------------------------------------------------------------------------------
    gravity = 6.5
    starterx = -10
    x = 125
    y = 559
    dac = 0
    dwc = 0
    gdc = 0
    gac = 0
    a = 23
    rax = 0
    ray = 0
    r = 0
    smolx = x
    anglifier = 0
    smoly = y
    shootingy = 0
    shootingx = 0
    angle = 0
    b = 0
    vel_x = 8
    vel_y = 21.5
    vel_y2 = 21.5
    island1x = 1250
    island3x = 1250
    island4x = 1250
    island2x = 1250
    island1y = 0
    island3y = 0
    island4y = 0
    island2y = 0
    pc = 0
    e1h = 0
    e2h = 0
    e3h = 0
    e4h = 0
    time1 = 0
    time2 = 0
    startmatch = time.time()
    #---------------------------------------------------------------------------------------------------
    #------------------------------------------running--------------------------------------------------
    #---------------------------------------------------------------------------------------------------
    while IsRunning:
        currenttime = time.time()
        runspeed = 5
        yes2b = button((255, 255, 255), 100, 50, 408, 325)
        no2b = button((255, 255, 255), 100, 50, 680, 325)
        qu2hb = button((255, 255, 255), 208, 49, 20, 28)
        qu2hb.draw(win)
        mpos = mx, my = pygame.mouse.get_pos() 
        keys = pygame.key.get_pressed()
        middleposx = mpx = x + AI1.get_width()/2
        middleposy = mpy = y + AI1.get_height()/2
        middlepos = mp = (mpx,mpy)
        rel_x, rel_y = mx - mpx, my - mpy                                                                #getting varriables and stuff
        radians = 0.0174533 * angle
        angle = int((180 / math.pi) * -math.atan2(rel_y, rel_x))                                         #code for the angle
        angle1 = angle + 50
        angle2 = angle 
        imgc = pygame.transform.rotate(AIM, angle1)
        imgc2 = pygame.transform.rotate(AIM2, angle2)
        if angle < 0:
            anglifier = 180 + angle
            angle = 180 + anglifier                                                                       #fixing angles
        clock = pygame.time.Clock()
    #---------------------------------------------------------------------------------------------------
    #----------------------------------------for events-------------------------------------------------
    #---------------------------------------------------------------------------------------------------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == K_d:
                    IswalkingLeft = False
                    IswalkingRight = True
                if event.key == K_a:
                    IswalkingLeft = True
                    IswalkingRight = False
            if event.type == pygame.KEYUP:
                if event.key == K_a:
                    IswalkingLeft = False
                    IswalkingRight = False
                if event.key == K_d:
                    IswalkingLeft = False
                    IswalkingRight = False
                if event.key == K_ESCAPE:
                    main_menu()
            if event.type == pygame.MOUSEBUTTONDOWN:    
                click = True
                if qu2hb.isOver(mpos):
                    menu = True
                if menu:
                    if yes2b.isOver(mpos):
                        main_menu()
                    if no2b.isOver(mpos):
                        menu = False


            if event.type == pygame.MOUSEBUTTONUP:
                attack = True
                click = False
                if keys[pygame.K_1]:
                    if CanShoot:
                        IsShooting = True
                        rax = math.cos(radians) * 20
                        ray = math.sin(radians) * 20
                        smolx = mpx
                        smoly = mpy

    #---------------------------------------------------------------------------------------------------
    #------------------------------------------movement-------------------------------------------------
    #---------------------------------------------------------------------------------------------------

        if keys[pygame.K_d]:
             x += vel_x
             IsRight = True
             IsLeft = False

        if keys[pygame.K_a]:
            x -= vel_x
            IsRight = False
            IsLeft = True

        if IsJumping is False and keys[pygame.K_SPACE]:
            jump.play()
            IsJumping = True
            OnPlat = False
            

        if Jump == False:
            if vel_y < 0:
                if vel_y > -22:
                    if keys[K_SPACE]:
                        Djump = True 

            if Djump == True:
                if OnPlat and vel_y2 < 0:
                    OnPlat = False
                    IsJumping = False
                    Djump = False 
                else:
                    IsJumping = False
                    vel_y = 23
                    y -= vel_y2
                    vel_y2 -= 0.7
            
            if IsJumping == True:
                if OnPlat and vel_y < 0:
                    vel_y =  23
                    OnPlat = False
                    IsJumping = False
                else:
                    y -=   vel_y
                    vel_y -= 0.7

            if vel_y2 < -23:
                vel_y2 = 23
                Djump = False
        
            if vel_y < -23:
                vel_y = 23
                IsJumping = False

        if Jump == True:
            if vel_y < 0:
                if vel_y > -25:
                    if keys[K_SPACE]:
                        Djump = True 

            if Djump == True:
                if OnPlat and vel_y2 < 0:
                    OnPlat = False
                    IsJumping = False
                    Djump = False 
                else:
                    IsJumping = False
                    vel_y = 26
                    y -= vel_y2
                    vel_y2 -= 0.7
            
            if IsJumping == True:
                if OnPlat and vel_y < 0:
                    vel_y =  26
                    OnPlat = False
                    IsJumping = False
                else:
                    y -=   vel_y
                    vel_y -= 0.7

            if vel_y2 < -26:
                vel_y2 = 26
                Djump = False
        
            if vel_y < -26:
                vel_y = 26
                IsJumping = False

        if Speed:
            vel_x = 12
        else:
            vel_x = 8

        if Slow:
            gravity = 4.5
        else:
            gravity = 6.5

        isl1box = pygame.draw.rect(win, (255,255,255), ((island1x ), (island1y - 50), 120, 50))
        isl2box = pygame.draw.rect(win, (255,255,255), ((island2x + 55), (island2y - 50), 120, 50))
        isl3box = pygame.draw.rect(win, (255,255,255), ((island3x + 40), (island3y - 50), 120, 50))
        isl4box = pygame.draw.rect(win, (255,255,255), ((island4x + 40), (island4y - 50), 120, 50))
        bullet = pygame.draw.rect(win, (255,255,255), ((smolx), (smoly), 20, 10))
        stop = pygame.draw.rect(win,(255,0,0), (1, 0, 1, 701))
        dinohit = pygame.draw.rect(win,(255,255,255), (x, y, 69, 100))
        attack_boxr = pygame.draw.rect(win, (255,255,255), ((x + 75), y, 75, 100))
        attack_boxl = pygame.draw.rect(win, (255,255,255), ((x - 75), y, 75, 100))
        #---------------------------------------------------------------------------------------------------
        #---------------------------------------------------------------------------------------------------
        win.blit(BG, (0,0))                                                                  #background || things you want to be begin the scenery go above this || things you want to be seen by the play go below
        #---------------------------------------------------------------------------------------------------
        #---------------------------------------------------------------------------------------------------
        if menu == True:
            no2b.draw(win)
            yes2b.draw(win)
            win.blit(QUIT, (345, 128))
    

        if click:
            if keys[pygame.K_1]:
                win.blit(imgc2,(mpx - int(imgc2.get_width()/2),mpy - int(imgc2.get_height()/2)))
            else:
                win.blit(imgc,(mpx - int(imgc.get_width()/2),mpy - int(imgc.get_height()/2)))
    
        if IsShooting:
            CanShoot = False
            imgcd = pygame.transform.rotate(DAGGER, angle1)
            bullet = pygame.draw.rect(win, (255,255,255), ((smolx), (smoly), 5, 5))
            win.blit(imgcd,(smolx - 13, smoly - 13))
            shootingx = int(smolx - mpx)
            shootingy = int(mpy - smoly)
            if shootingx < -400:
                CanShoot = True
                IsShooting = False
            if shootingx > 400:
                CanShoot = True
                IsShooting = False  
            if shootingy < -400: 
                CanShoot = True
                IsShooting = False
            if shootingy > 400:
                CanShoot = True
                IsShooting = False  

        if Res:
            win.blit(RS, (92, 152))
        if Speed:
            win.blit(SPD, (20, 86))
        if Slow:
            win.blit(SLF, (20, 152))
        if Jump:
            win.blit(JPB, (92, 86))

        if dwc + 1 >= 36:
            dwc = 0

        if a == 23:
            y += gravity

        if dac + 1 >= 36:
            dac = 0
            attack = False

        if gac + 1 >= 36:
            gac = 0
            if Res:
                pass
            else:
                dead = True
            
        if Res:
            win.blit(RES_SHEILD, (x + 3,y))

        if gdc + 1 >= 36:
            gdc = 0 
            ep = 0

            enemyplaced = False
            enemyp1 = False
            enemyp2 = False
            enemyp3 = False
            enemyp4 = False

        timetime = currenttime - startmatch
        if timetime == 100:
            runspeed = 6
        if timetime == 200:
            runspeed = 8
        if timetime == 500:
            runspeed = 10
        if timetime == 1000:
            runspeed = 13
        if timetime == 2000:
            runspeed = 16
        if timetime == 5000:
            runspeed = 20




        #---------------------------------------------------------------------------------------------------
        #----------------------------------image blits and updates------------------------------------------
        #---------------------------------------------------------------------------------------------------
        win.blit(QUITTING,(20, 20))
        if IsRight:
            smolx += rax
            smoly -= ray
            if attack:
                win.blit(AA1[dac//3], (x,y))
                attackboxr = True
                attackboxl = False
                dac += 1
            elif IswalkingRight:
                win.blit(AR1[dwc//6], (x,y))
                dwc += 1
            elif IswalkingRight == False:
                win.blit(AI1, (x,y))
        if IsLeft:
            smolx += rax
            smoly -= ray
            if attack:
                win.blit(AA2[dac//3], (x,y))
                attackboxr = False
                attackboxl = True
                dac += 1
            elif IswalkingLeft:
                win.blit(AR2[dwc//6], (x,y))
                dwc += 1
            elif IswalkingLeft == False:
                win.blit(AI2, (x,y))
        placement = [1,2,3,4,5]
        powerup_chance = [1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,11,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,11,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,11,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,11,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,11,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2]
        powerup_place = [1,2,3,4]
        enemy_place_ = [1,2,3,4]
        pc = random.choice(powerup_chance)
        pp = 0
        ep = 0
        if pc == 2:
            pp = random.choice(powerup_place)
            Place_powerup = True

        if pc == 3:
            if enemyplaced == False:
                ep = random.choice(enemy_place_)
                Enemy_Place = True
            else:
                pass


        if Isl1place == False:
            place1 = random.choice(placement)
            if IslDrw:
                IslDrw = False
                Isl1move = True
                Isl1place = True

        if Isl1move:
            island1y = (116 * place1)
            island1 = pygame.draw.rect(win, (255,255,255), (island1x, island1y, 150, 49))
            win.blit(ISL_1, ((island1x - 50), (island1y - 5)))
            island1x -= runspeed
            if island1x < -200:
                island1x = 1250
                Isl1place = False
                power1 = False
            if island1x == 940:
                IslDrw = True
            if pp == 1:
                power1 = True
            if ep == 1:
                enemyp1 = True 
                enemyplaced = True

        if Isl2place == False:
            place2 = random.choice(placement)
            if IslDrw:
                IslDrw = False
                Isl2move = True
                Isl2place = True
        
        if Isl2move:
            island2y = (116 * place2)
            island2 = pygame.draw.rect(win, (255,255,255), (island2x, island2y, 235, 50))
            win.blit(ISL_5, ((island2x - 25), (island2y - 8)))
            island2x -= runspeed
            if island2x < -200:
                island2x = 1250
                Isl2place = False
                power2 = False
            if island2x == 940:
                IslDrw = True
            if pp == 2:
                power2 = True
            if ep == 2:
                enemyp2 = True
                enemyplaced = True

        if Isl3place == False:
            place3 = random.choice(placement)
            if IslDrw:
                IslDrw = False
                Isl3move = True
                Isl3place = True
        if Isl3move:
            island3y = (116 * place3)
            island3 = pygame.draw.rect(win, (255,255,255), (island3x, island3y, 200, 50))
            win.blit(ISL_3, ((island3x - 20), (island3y - 8)))
            island3x -= runspeed
            if island3x < -200:
                island3x = 1250
                Isl3place = False
                power3 = False
            if island3x == 940:
                IslDrw = True
            if pp == 3:
                power3 = True
            if ep == 3:
                enemyp3 = True
                enemyplaced = True

        if Isl4place == False:
            place4 = random.choice(placement)
            if IslDrw:
                IslDrw = False
                Isl4move = True
                Isl4place = True

        if Isl4move:
            island4y = (116 * place4)
            island4 = pygame.draw.rect(win, (255,255,255), (island4x, island4y, 250, 40))
            win.blit(ISL_4, ((island4x - 10), (island4y - 8)))
            island4x -= runspeed
            if island4x < -200:
                 island4x = 1250
                 Isl4place = False
                 power4 = False
            if island4x == 940: 
                IslDrw = True
            if pp == 4:
                power4 = True
            if ep == 4:
                enemyp4 = True
                enemyplaced = True

        if Place_powerup:
            if power1:
                power1r = pygame.draw.rect(win,(255,0,0),(island1x + 50 + 20, island1y - 50 + 20, 10, 10))
                win.blit(SPEED, ((island1x + 50), (island1y - 50)))
                if power1r.colliderect(dinohit):
                    Speed = True
                    power1 = False
                    taketime = True
            if power2:
                power2r = pygame.draw.rect(win,(255,0,0),(island2x + 100 + 20, island2y - 50 + 20, 10, 10))
                win.blit(JUMP, ((island2x + 100), (island2y - 50)))
                if power2r.colliderect(dinohit):
                    Jump = True 
                    taketime = True
                    power2 = False
            if power3:
                power3r = pygame.draw.rect(win,(255,0,0),(island3x + 69 + 20, island3y - 50 + 20, 5, 5))
                win.blit(SLOW, ((island3x + 75), (island3y - 50)))
                if power3r.colliderect(dinohit):
                    taketime = True
                    Slow = True
                    power3 = False
            if power4:
                power4r = pygame.draw.rect(win,(255,0,0),(island4x + 125 + 20, island4y - 50 + 20, 5, 5))
                win.blit(RES, ((island4x + 123), (island4y - 50)))
                if power4r.colliderect(dinohit):
                    taketime = True
                    Res = True
                    power4 = False

        if Enemy_Place:
            if enemyp1:
                enemyplaced = True
                enemy1 = pygame.draw.rect(win,(255,0,0),(island1x + 55 , island1y - 40 , 17, 30))
                if enemy1.colliderect(bullet):
                    edie.play()
                    IsShooting = False
                    enemyplaced = False
                    enemyp1 = False
                if enemy1.colliderect(attack_boxr) and click:
                    enemyp1 = False
                    enemyplaced = False
                    edie.play()
                if enemy1.colliderect(attack_boxl) and click:
                    enemyp1 = False
                    enemyplaced = False
                    edie.play()
                if idle == False:
                    win.blit(GLIR, (island1x + 37 , island1y - 75))
                if isl1box.colliderect(dinohit):
                    idle = True
                    if (island1x + 37) - x < 0:
                        win.blit(GLARR[gac//6],(island1x + 37, island1y - 75))
                        gac += 1
                    else:  
                        win.blit(GLARL[gac//6],(island1x + 37, island1y - 75))
                        gac += 1
                else:
                    idle = False
            if enemyp2: 
                enemyplaced = True
                enemy2 = pygame.draw.rect(win,(255,0,0),(island2x + 110 , island2y - 40 , 17, 30))
                if enemy2.colliderect(bullet):
                    enemyp2 = False
                    enemyplaced = False
                    edie.play()
                    IsShooting = False
                if enemy2.colliderect(attack_boxr) and click:
                    enemyplaced = False
                    enemyp2 = False
                    edie.play()
                if enemy2.colliderect(attack_boxl) and click:
                    enemyp2 = False
                    enemyplaced = False
                    edie.play()
                if idle == False:
                    win.blit(GLIR, (island2x + 92 , island2y - 75))
                if isl2box.colliderect(dinohit):
                    idle = True
                    if (island2x + 92) - x < 0:
                        win.blit(GLARR[gac//6],(island2x + 92, island2y - 75))
                        gac += 1
                    else:  
                        win.blit(GLARL[gac//6],(island2x + 92, island2y - 75))
                        gac += 1
                else:
                    idle = False
            if enemyp3:
                enemyplaced = True
                win.blit(GLI, (island3x + 77 , island3y - 75))        
                enemy3 = pygame.draw.rect(win,(255,0,0),(island3x + 95 , island3y - 40 , 17, 30))
                if enemy3.colliderect(bullet):
                    enemyp3 = False
                    enemyplaced = False
                    edie.play()
                    IsShooting = False
                if enemy3.colliderect(attack_boxr) and click:
                    enemyplaced = False
                    enemyp3 = False
                    edie.play()
                if enemy3.colliderect(attack_boxl) and click:
                    enemyplaced = False
                    enemyp3 = False
                    edie.play()
                if idle == False:
                    win.blit(GLI, (island3x + 77 , island3y - 75))
                if isl3box.colliderect(dinohit):
                    idle = True
                    if (island3x + 77) - x < 0:
                        win.blit(GLAR[gac//6],(island3x + 77, island3y - 75))
                        gac += 1
                    else:  
                        win.blit(GLAL[gac//6],(island3x + 77, island3y - 75))
                        gac += 1
                else:
                    idle = False
            if enemyp4:
                enemyplaced = True
                enemy4 = pygame.draw.rect(win,(255,0,0),(island4x + 95 , island4y - 40 , 17, 30))
                win.blit(GLI, (island4x + 77 , island4y - 75))
                if enemy4.colliderect(bullet):
                    enemyp4 = False
                    enemyplaced = False
                    edie.play()
                    IsShooting = False
                if enemy4.colliderect(attack_boxr) and click:
                    edie.play()
                    enemyplaced = False
                    enemyp4 = False
                if enemy4.colliderect(attack_boxl) and click:
                    enemyplaced = False
                    edie.play()
                    enemyp4 = False
                if idle == False:
                    win.blit(GLI, (island4x + 77 , island4y - 75))
                if isl4box.colliderect(dinohit):
                    idle = True
                    if (island4x + 77) - x < 0:
                        win.blit(GLAR[gac//6],(island4x + 77, island4y - 75))
                        gac += 1
                    else:  
                        win.blit(GLAL[gac//6],(island4x + 77, island4y - 75))
                        gac += 1
                else:
                    idle = False

        if OnPlat:
            x -= 5
            if Speed == False:
                if IsLeft:
                    vel_x = 3
                if IsRight:
                    vel_x = 13
            if Speed:
                if IsLeft:
                    vel_x = 7
                if IsRight:
                    vel_x = 17

        starter = pygame.draw.rect(win, (255,255,255), (starterx, 655, 340, 100))
        win.blit(STRTISL, (starterx - 13, 531))

        if stop.colliderect(dinohit):
            x = 1

        if starter.colliderect(dinohit):
            if abs(dinohit.bottom - starter.top) < 50:
                y = 559

        if Isl1place:
            if island1.colliderect(dinohit):
                OnPlat = True
                if abs(dinohit.bottom - island1.top) < 50:
                    y = island1y - 97

        if Isl2place:
            if island2.colliderect(dinohit):
                OnPlat = True
                if abs(dinohit.bottom - island2.top) < 50:
                    y = island2y - 97

        if Isl3place:
            if island3.colliderect(dinohit):
                OnPlat = True
                if abs(dinohit.bottom - island3.top) < 50:
                    y = island3y - 97

        if Isl4place:
            if island4.colliderect(dinohit):
                OnPlat = True
                if abs(dinohit.bottom - island4.top) < 50:
                    y = island4y - 97
            
        if taketime:
            time1 = time.time()
            taketime = False
        
        time2 = time.time()

        if time2 - time1 >= 10:
            Speed = False
            Res = False
            Jump = False
            Slow = False 
            time1 = 0

        if keys[K_SPACE]:
            startermove = True
        
        if startermove:
            starterx -= 5


        if y > 800:
            dead = True
        

        if dead:
            Game_Over()
            
        pygame.display.update()
        clock.tick(60)

def Game_Over():
    pdie.play()
    while True:
        abhb2 = button((255, 255, 255), 208, 49, 387, 484)
        playhb2 = button((255, 255, 255), 440, 62, 380, 420)
        quhb2 = button((255, 255, 255), 208, 49, 605, 491)
        abhb2 = button((255, 255, 255), 208, 49, 342, 464)
        win.blit(BG, (0,0))
        win.blit(GameOver, (345, 128))
        win.blit(PLAY,(380, 420))
        win.blit(ABOUT, (342, 464))
        win.blit(QUITTING, (602, 482))
        keys = pygame.key.get_pressed()
        mpos = pygame.mouse.get_pos() 
        clock = pygame.time.Clock()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if playhb2.isOver(mpos):
                    game()
                if quhb2.isOver(mpos):
                    main_menu()
                if abhb2.isOver(mpos):
                    Aboutme()
        pygame.display.update()
        clock.tick(60)

def Aboutme():
    while True:
        playhb3 = button((255, 255, 255), 440, 62, 380, 420)
        quhb3 = button((255, 255, 255), 208, 49, 605, 491)
        win.blit(BG, (0,0))
        win.blit(ABOUT_ME, (345, 128))
        win.blit(PLAY,(380, 420))
        win.blit(ABOUT, (342, 464))
        win.blit(QUITTING, (602, 482))
        keys = pygame.key.get_pressed()
        mpos = pygame.mouse.get_pos() 
        clock = pygame.time.Clock()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if playhb3.isOver(mpos):
                    game()
                if quhb3.isOver(mpos):
                    main_menu()   
        pygame.display.update()
        clock.tick(60)
main_menu()